# README

## Co tato složka obsahuje

V rámci této složky najdeme soubory potřebné ke spuštění programu.
Dále si do této složky stáhněte nacrawlovaná data z prvního cvičení a pojmenujte soubor output_prod.csv

V rámci skriptu run a runModel je připravené spuštění modelu pomocí skriptu jak pro předučený model se souborem,
tak model bez skriptu.

Ve skriptu je nutné upravit cestu k instalaci JavaFX.
