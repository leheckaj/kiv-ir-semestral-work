package utils;

public class Constants {
    public static final String INPUT_DATA_CSV_FILE = "output_prod.csv";
}
