package tfidf;

public class Constants {

    public static final int DOCUMENT_COUNT = 3;
}
